
public class PS3 {
    
    public static int findSumInRange(int[] array, int L, int R) {
        if (array == null || L < 0 || R >= array.length || L > R) {
            throw new IllegalArgumentException("Invalid input");
        }
        
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += array[i];
        }
        
        return sum;
    }
    
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int L = 2;
        int R = 6;
        
        int sum = findSumInRange(array, L, R);
        System.out.println("The sum of elements from index " + L + " to " + R + " is: " + sum);
    }
}
