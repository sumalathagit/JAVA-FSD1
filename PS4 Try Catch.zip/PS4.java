
public class PS4 {
  public static void main(String[] args) {
	  int  arr[]= {2,4,3};
	  
    try {
      
      int num1 = Integer.parseInt(args[0]);
      int num2 = Integer.parseInt(args[1]);
   
      int result = num1+ num2;
      System.out.println("Result: " + result);
    } 
    catch (ArithmeticException e) {
       
      System.out.println("Error: " + e.getMessage());
    } 
    
 catch (Exception e) {
       
      System.out.println("Error: " + e.getMessage());
    } 
    finally {
       
      System.out.println("Done.");
    }
  }
}
