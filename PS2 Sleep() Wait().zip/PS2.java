  
public class PS2{
	private static Object LOCK = new Object();
	 public static void main(String[] args) throws InterruptedException {
		PS2 ps2=new PS2();
		System.out.println("Hi");
        PS2.timea();
        System.out.println("How are you");
        PS2.timeb();
        System.out.println("Bye");
        synchronized(LOCK) {
        	LOCK.wait(1000);
        }
	}
	
	public static void timea() {
		try {
			Thread.sleep(1000);
		}
		catch(Exception e){
			
		}
	 
	}
	public static void timeb()
	{
		try {
			Thread.sleep(2000);
		}
		catch(Exception e) {
			
		}
	}
	 
	
	
}
 