package AccessSpecifiers;

public class Public2  {

		public static void main(String[] args) {
			Public obj = new Public ();   
		       obj.display();  
		}

		private void display() {
			// TODO Auto-generated method stub
			
		}

	}


