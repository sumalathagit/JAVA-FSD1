package AccessSpecifiers;

class A
{
	//private method 
	private int i=10;
	
	public void display () {
		System.out.println(i);
		System.out.println("I am protected");
	}
}
class B extends A{
	public void access(int c) {
		System.out.println(c);
		display();
	}
}

public class privateAccessModifiers {

public static void main(String[] args) {
	A a =new A();
	   a.display();
	   
	   
}	
	
}

 


