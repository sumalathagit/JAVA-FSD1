package AccessSpecifiers;

//Public Modifier

 

public class Public{
	
	public void display() 
  { 
      System.out.println("This is public access specifier"); 
  } 
}




