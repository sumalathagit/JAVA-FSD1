import java.util.Stack;

public class PS8 extends StackCls{
public static void main(String[] args) {
 StackCls s=new StackCls();
 
 s.push(10+"\n" );
 s.push(20+"\n" );
 s.push(31+"\n");
 s.push(32+"\n");
 s.push(33+"\n");
 s.push(34+"\n");
 s.push(10+"\n");
 System.out.print("popped from stack "+s.pop());
 while(!s.isEmpty()) {
	s.pop();
	 
	 
 }
	
}
}
//we can even write this stack in a simple way
/* 
 public class PS9{
	public static void main(String[] args) {
		Stack s=new Stack();
		s.add(10);
		s.add(20);
		s.add(30);
		s.add(40);
		System.out.println(s.pop()+"is the poped element");
		while(!s.isEmpty()) {
			System.out.println(s.pop());
		}
	}
}
 */
 

