
//import Outer.InnerClass;

public class OuterTest extends Outer {
public static void main(String[] args) {
	Outer.InnerClass.InnerClassMethod();
	InnerClass innerclass=new Outer.InnerClass();
	InnerClass.nonStaticMethod();
}
}
