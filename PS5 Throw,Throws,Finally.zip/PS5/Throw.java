package PS5;

public class Throw {
 static void check(int age) {
	if(age<18) {
		throw new ArithmeticException("Not eligible");
	}
	else
		System.out.println("You are In");
}
 public static void main(String[] args) {
	check(17);
	System.out.println("Hey");
}
 
}
