package PS5;

public class ThrowsAndFinally {
int div(int a,int b)throws ArithmeticException{
	int c=a/b;
	return c;
}

public static void main(String[] args) {
	ThrowsAndFinally t=new ThrowsAndFinally();
	try {
		System.out.println(t.div(0,0));
	}
	catch(ArithmeticException e){
		System.out.println("Exception occured");
	}
	finally {
		System.out.println("Finally block is executed");
	}
	 
}

}
