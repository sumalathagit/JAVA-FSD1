 
package PS5;

class NewException extends Exception{
	int a;
	NewException(int b){
		a=b;
	}
	public String toString() {
		return ("exception"+a);
		
	}
	}
		
	
public class CustomException {
public static void main(String[] args) {
	try {
		throw new NewException(11); 
	}
	catch(NewException e) {
		System.out.println(e.toString());
	}
}
}
