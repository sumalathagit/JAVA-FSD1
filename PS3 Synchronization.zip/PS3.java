
class MainThread{
	synchronized void print(int n) {
		for(int i=1;i<5; i++) {
			System.out.println(i+n);
			try {
				Thread.sleep(1000);
			}
			catch(Exception e) {
				
			}
		 
		}
	}
}
class Thread1 extends Thread{
	MainThread s;
	Thread1(MainThread s){
		this.s=s;
	}
		public void  run() {
			System.out.println(10);
		
	}
	
}
	class Thread2 extends Thread{
		MainThread s;
		Thread2(MainThread s){
			this.s=s;
		}
			public void  run() {
				System.out.println(101);
			
		}
		
	}
 
public class PS3 {
public static void main(String[] args) {
	MainThread m=new MainThread();
	Thread1 t1=new Thread1(m);
	Thread2 t2=new Thread2(m);
	t1.start();
	t2.start();
}
}
