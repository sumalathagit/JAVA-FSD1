
import java.util.Set;
import java.util.TreeMap;

import javax.swing.text.html.HTMLDocument.Iterator;

public class MapDemo{
	 public static void main(String[] args) {
		 TreeMap m=new TreeMap();
		 m.put("java", 60);
		 m.put("python",70);
		 m.put("C", 80);
		 m.put("Django", 20);
		 Set s=m.keySet();
   java.util.Iterator i= s.iterator();
		while(i.hasNext()){
			 Object key= i.next();
			 Object value=m.get(key);
			 System.out.println(key + "=" + value);
		 }
	}
 }