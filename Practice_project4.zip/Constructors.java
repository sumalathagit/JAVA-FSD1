

class B
{
	 
	public B()
	  {
		  System.out.println("This is no argument constructor");
	  }
	  public B(int a) {
		  System.out.println("I am argumented Constructor");  
		  System.out.println(a);
	  }
}
public class Constructors {

	 

	public static void main(String[] args) {
		//This is no argument constructor
		B b1=new B();
		  
		 //int a=2;
// This is argumented constructor
		B b2=new B(2);
		
		 
	}

}
