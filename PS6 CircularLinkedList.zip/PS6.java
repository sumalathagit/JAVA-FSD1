

public class PS6  {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);

         
        if (head == null) {
            head = newNode;
            head.next = head; 
            return;
        }

       
        if (data < head.data) {
            newNode.next = head;
            head = newNode;
            updateLastNode();  
            return;
        }

       
        Node current = head;
        while (current.next != head && data > current.next.data) {
            current = current.next;
        }

        
        newNode.next = current.next;
        current.next = newNode;
        updateLastNode();  
    }

    private void updateLastNode() {
        
        Node current = head;
        while (current.next != head) {
            current = current.next;
        }
        current.next = head;
    }

    public void displayList() {
        if (head == null) {
            System.out.println("The list is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
    class Node{
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null; }
        
    }

    public static void main(String[] args) {
        PS6 circularLinkedList = new PS6();

         
        circularLinkedList.insert(1);
        circularLinkedList.insert(3);
        circularLinkedList.insert(5);
        circularLinkedList.insert(7);
        circularLinkedList.insert(9);

        System.out.println("Original sorted circular linked list:");
        circularLinkedList.displayList();

        int elementToInsert = 6;
        circularLinkedList.insert(elementToInsert);

        System.out.println("Sorted circular linked list after inserting " + elementToInsert + ":");
        circularLinkedList.displayList();
    }
}

