class MyThread extends Thread{
	public void run() {
		System.out.println("Extended Thread class");
	}
}
class MyRunnable implements Runnable{
	public void run() {
		System.out.println("Implemented Runnable Interface");
	}
}
public class PS1{
	public static void main(String[] args) {
		MyThread mt=new MyThread();
		mt.run();
		
		MyRunnable mr=new MyRunnable();
		mr.run();
	}
}