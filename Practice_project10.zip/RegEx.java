
  
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegEx {

	public static void main(String[] args) {
		 
		//Pattern p = Pattern.compile("n");
		//Matcher m = p.matcher("account");
	Pattern p =Pattern.compile("a");
	Matcher m = p.matcher("Javapython");
		 while(m.find())
		System.out.println(m.start()+","+m.end()+","+m.group());
	
	}
}

 