import java.io.*;
public class PS4 {
public static void main(String[] args) {
	int[][] a= {
			{1,2,3},
			{4,5,6},
			{7,8,9}
	};
	int[][] b= {
			{1,2,3},
			{4,5,6},
			{7,8,9}
	};
	int len=a.length;
	int[][] c=new int[len][len];
	multiply(a,b,c);
	displayMatric(c);
	
}
 
private static void multiply(int[][] a, int[][] b, int[][] c) {
	 int len=a.length;
	 for(int i=0;i<len;i++) {
	 
	 for(int j=0;j<len;j++) {
		 for(int k=0;k<len;k++) {
			 c[i][j]+=a[i][k]*b[k][j];
	 
		 }
		 }
	 }
}
private static void displayMatric(int[][] c) {
	 for(int[]temp:c) {
		 for(int n:temp) {
			 System.out.println(n+"\t");
		 }
		 System.out.println();
	 }
	
}

	 



 
}
