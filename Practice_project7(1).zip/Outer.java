

 
 class Outer{
	 public static class InnerClass{
		 
	 
	public static void InnerClassMethod() {
		
		System.out.println("InnerClass() of InnerClassMethod()");
		
	}
	public static void nonStaticMethod() {
		System.out.println("non static method in InnerClass");
	}
		
	 }
}

 