import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

public class PS9 {
public static void main(String[] args) {
	Queue q=new  PriorityQueue();
	q.add(40);
	q.add(30);
	q.add(20);
	q.add(10);
	q.add(60);
	System.out.println(q.poll()+"is the polled element");
while(!q.isEmpty()) {
	System.out.println(q.poll());
	//q.poll();
}
}
}
