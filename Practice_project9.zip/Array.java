
import java.util.Scanner;

public class Array {
public static void main(String[] args) {
	Scanner scn=new Scanner(System.in);
	System.out.println("Enter size of array:");
	int size=scn.nextInt();
	int[] arr=new int[size];
	System.out.println("Enter array elements");
	for(int i=0; i<arr.length; i++) {
		arr[i]=scn.nextInt();
		
	}
	System.out.println("Enter array elements");
	for(int i=0; i<arr.length; i++) {
		
	System.out.println(arr[i]+ " ");

}
}
}
