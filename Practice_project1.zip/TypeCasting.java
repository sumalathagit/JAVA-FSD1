
public class TypeCasting {
	
	public static void main(String[] args) {
		
		//implicit type casting
		char b='a';
		int a=b;
		
		//explicit type casting
		double d=10.5;
		int c= (int)d;
		
		//Float is bigger than long
		float l=134f;
		long g=(long)l;
		System.out.println(a);
		System.out.println(c);
		System.out.println(g);
	}

}