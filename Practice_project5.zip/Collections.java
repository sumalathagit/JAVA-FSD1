 
 
import java.util.ArrayList;
import java.util.HashSet;

public class Collections {
    public static void main(String[] args) {
        // Create an ArrayList to store integers
        ArrayList<Integer> myArrayList = new ArrayList<Integer>();
        
        // Add some elements to the ArrayList
        myArrayList.add(10);
        myArrayList.add(20);
        myArrayList.add(30);
        myArrayList.add(20); // Adding a duplicate element
        
        // Print the contents of the ArrayList
        System.out.println("The contents of the ArrayList are:");
        for (int number : myArrayList) {
            System.out.println(number);
        }
    }
    }
        
