import java.util.Scanner;


import java.util.*;

public class PS2 {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>(Arrays.asList(5, 2, 9, 1, 7, 3, 6, 8, 0));

        int fSmallest = findFSmallest(numbers);
        System.out.println("The fourth smallest element is: " + fSmallest);
    }

    public static int findFSmallest(List<Integer> numbers) {
        if (numbers == null || numbers.size() < 4) {
            throw new IllegalArgumentException("The list should have at least 4 elements.");
        }

        PriorityQueue<Integer> pq = new PriorityQueue<>(numbers);

         
        for (int i = 0; i < 3; i++) {
            pq.poll();
        }

        return pq.poll();
    }
}
