
public class PS2_Binary {
public static void main(String[] args) {
	int[] a= {3,4,1,7,2,9};
	System.out.println(search(a,9));
	System.out.println(search(a,3));
}

private static int search(int[] a, int ele) {
	// TODO Auto-generated method stub
	int start=0,end=a.length-1;
	while(start<=end) {
		int mid=(start+end)/2;
		if(ele==a[mid]) return mid;
		else if(ele<a[mid]) end=mid-1;
		else start=mid+1;
	}
	return -1;
}
}
