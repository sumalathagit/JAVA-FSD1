
import java.util.Arrays;

public class PS3_Exponential {
    public static void main(String[] args) {
        int[] arr = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
        int key = 23;
        int index = exponentialSearch(arr, key);
        if (index == -1) {
            System.out.println("Element not found.");
        } else {
            System.out.println("Element found at index " + index);
        }
    }

    private static int exponentialSearch(int[] arr, int key) {
        if (arr[0] == key) {
            return 0;
        }

        int i = 1;
        while (i < arr.length && arr[i] <= key) {
            i = i * 2;
        }

        return Arrays.binarySearch(arr, i / 2, Math.min(i, arr.length), key);
    }
}
