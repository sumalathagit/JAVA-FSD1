
public class PS1_Linear {
public static void main(String[] args) {
	int[] a= {3,5,1,2,8,5};
	System.out.println(search(a,8));
	System.out.println(search(a,10));
}

private static int search(int[] a, int ele) {
	// TODO Auto-generated method stub
	for(int i=0;i<a.length;i++) {
		if(ele==a[i]) return i;
		
	}
	
	return -1;
}
}
