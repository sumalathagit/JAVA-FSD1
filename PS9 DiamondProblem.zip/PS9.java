
interface Animal {
    public void eat();
    public void move();
}

interface Mammal extends Animal {
    public void breathe();
}

interface Reptile extends Animal {
    public void crawl();
}

class Platypus implements Mammal, Reptile {
    public void eat() {
        System.out.println("Platypus is eating");
    }
    public void move() {
        System.out.println("Platypus is moving");
    }
    public void breathe() {
        System.out.println("Platypus is breathing");
    }
    public void crawl() {
        System.out.println("Platypus is crawling");
    }
}

public class PS9 {
    public static void main(String[] args) {
        Platypus  p = new Platypus();
        p.eat();
        p.move();
        p.breathe();
        p.crawl();
    }
}
